class homeObjects:

    LOGIN_BTN       = '//a[@href="/pages/dashboard.html"]'
    ADMIN_LOGIN_BTN = '//a[@href="/admin/pages/dashboard.html"]'
